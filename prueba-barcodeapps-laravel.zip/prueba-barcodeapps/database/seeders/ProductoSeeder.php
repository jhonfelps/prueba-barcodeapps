<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::table('productos')->insert([
        "categoria_id"=>"1",
        "nombre"=>"lápiz",
        "codigo"=>"cp1",
        "color"=>"amarillo",
        "precio"=>"1500",
      ]);
      DB::table('productos')->insert([
        "categoria_id"=>"1",
        "nombre"=>"esfero",
        "codigo"=>"cp2",
        "color"=>"azul",
        "precio"=>"2000",
      ]);
      DB::table('productos')->insert([
        "categoria_id"=>"1",
        "nombre"=>"borrador",
        "codigo"=>"cp3",
        "color"=>"verde",
        "precio"=>"400",
      ]);
      DB::table('productos')->insert([
        "categoria_id"=>"1",
        "nombre"=>"taja lápiz",
        "codigo"=>"cp4",
        "color"=>"naranja",
        "precio"=>"950",
      ]);
      DB::table('productos')->insert([
        "categoria_id"=>"1",
        "nombre"=>"regla",
        "codigo"=>"cp5",
        "color"=>"roja",
        "precio"=>"2800",
      ]);
      DB::table('productos')->insert([
        "categoria_id"=>"1",
        "nombre"=>"maleta",
        "codigo"=>"cp6",
        "color"=>"rosada",
        "precio"=>"17500",
      ]);
      DB::table('productos')->insert([
        "categoria_id"=>"2",
        "nombre"=>"balón de futbol",
        "codigo"=>"bp1",
        "color"=>"blanco",
        "precio"=>"25000",
      ]);
      DB::table('productos')->insert([
        "categoria_id"=>"2",
        "nombre"=>"medias",
        "codigo"=>"bp2",
        "color"=>"amarillas",
        "precio"=>"5200",
      ]);
      DB::table('productos')->insert([
        "categoria_id"=>"2",
        "nombre"=>"toalla",
        "codigo"=>"bp3",
        "color"=>"morada",
        "precio"=>"14500",
      ]);
      DB::table('productos')->insert([
        "categoria_id"=>"2",
        "nombre"=>"tennis",
        "codigo"=>"bp4",
        "color"=>"negros",
        "precio"=>"150000",
      ]);
      DB::table('productos')->insert([
        "categoria_id"=>"2",
        "nombre"=>"sudadera",
        "codigo"=>"bp5",
        "color"=>"negra",
        "precio"=>"68800",
      ]);
      DB::table('productos')->insert([
        "categoria_id"=>"2",
        "nombre"=>"pantaloneta",
        "codigo"=>"bp6",
        "color"=>"verde",
        "precio"=>"21000",
      ]);
    }
}
