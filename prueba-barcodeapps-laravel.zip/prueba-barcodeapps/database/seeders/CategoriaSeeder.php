<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategoriaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::table('categorias')->insert([
        "id"=>1,
        "nombre"=>"Utiles Escolares",
        "descripcion"=>"utiles para los estudiantes y para la oficina",
      ]);
      DB::table('categorias')->insert([
        "id"=>2,
        "nombre"=>"Deporte",
        "descripcion"=>"Ropa y accesorios deportivos",
      ]);
    }
}
