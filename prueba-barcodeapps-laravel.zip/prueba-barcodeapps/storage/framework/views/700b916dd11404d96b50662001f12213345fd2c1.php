
<?php $__env->startSection('content'); ?>
<div class="header bg-naranja pb-6">
            <div class="container-fluid">
                <div class="header-body">
                    <div class="row align-items-center py-4">
                        <div class="col-lg-6 col-7">
                            <h6 class="h2 text-white d-inline-block mb-0">Editar Prodcuto</h6>
                        </div>
                        <div class="col-lg-6 col-5 text-right">
                            <a href="home" class="btn btn-sm btn-neutral naranjabold">Listado de Productos</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid mt--6">
            <!-- Table -->
            <div class="row justify-content-center">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row align-items-center">
                                <div class="col-8">
                                    <h3 class="mb-0">Formulario de Edición de Producto</h3>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                          <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <span class="alert-text"><strong>Muy bien! </strong><?php echo \Session::get('success'); ?></span>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Cerrar">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <?php endif; ?>
                            <form action="UpdateProduct" method="post" role="form" enctype="multipart/form-data">
                              <?php echo e(csrf_field()); ?>

                              <?php $__currentLoopData = $producto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="pl-lg-4">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-digito-verificacion">Categoría</label>
                                                <select class="form-control" id="categoria_id" name="categoria_id">
                                                    <option value="<?php echo e($product->categoria_id); ?>" selected><?php echo e($product->nombrecat); ?></option>
                                                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($cate->id); ?>"><?php echo e($cate->nombre); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-nombre">Nombre</label>
                                                <input type="text" id="input-nombre" name="nombre" required class="form-control" value="<?php echo e($product->nombre); ?>">
                                                <input type="hidden" name="id" value="<?php echo e($product->id); ?>"/>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-first-name">Código</label>
                                                <input type="text" id="input-codigo" name="codigo" required class="form-control" placeholder="Código" value="<?php echo e($product->codigo); ?>">
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-first-name">Color</label>
                                                <input type="text" id="input-color" name="color" required class="form-control" placeholder="Color" value="<?php echo e($product->color); ?>">
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-first-name">Precio</label>
                                                <input type="number" id="input-precio" name="precio" required class="form-control" value="<?php echo e($product->precio); ?>">
                                            </div>
                                        </div>
                                      <div class="col-lg-12">
                                          <div class="text-center">
                                              <button type="submit" value="Guardar" class="btn btn-primary mt-4">Guardar</button>
                                          </div>
                                      </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prueba-barcodeapps\resources\views/editarproducto.blade.php ENDPATH**/ ?>