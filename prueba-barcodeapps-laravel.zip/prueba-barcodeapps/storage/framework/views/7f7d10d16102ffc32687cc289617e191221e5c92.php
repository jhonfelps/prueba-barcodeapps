
<?php $__env->startSection('content'); ?>
<div class="header bg-naranja pb-6">
        <div class="container-fluid">
            <div class="header-body">
                <div class="row align-items-center py-4">
                    <div class="col-lg-6 col-7">
                        <h6 class="h2 text-white d-inline-block mb-0">PRUEBA BARCODEAPPS</h6>
                    </div>
                    <div class="col-lg-6 col-5 text-left">
                        <a href="Crear-Categoria" class="btn btn-sm btn-warning btn-round btn-icon" data-toggle="tooltip" data-original-title="">
                            <span class="btn-inner--icon"><i class="fas fa-plus"></i></span>
                            <span class="btn-inner--text">Crear Categoría</span>
                        </a>
                        <a href="home" class="btn btn-sm btn-neutral naranjabold">Listado de Productos</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid mt--6">
        <div class="card">
            <!-- Card header -->
            <div class="card-header border-0">
                <div class="row">
                    <div class="col-6">
                        <h3 class="mb-0">Categorías</h3>
                    </div>
                </div>
            </div>
            <!-- Light table -->
            <div class="table-responsive">
                <table class="table align-items-center table-flush">
                    <thead class="thead-light">
                        <tr>
                            <th>Id</th>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td class="table-user">
                              <b><?php echo e($cate->id); ?></b>
                          </td>
                            <td class="table-user">
                                <b><?php echo e($cate->nombre); ?></b>
                            </td>
                            <td class="table-user">
                                <?php echo e($cate->descripcion); ?>

                            </td>
                            <td class="table-user">
                              <a href="editar-categoria=<?php echo e($cate->id); ?>" class="table-action" data-toggle="tooltip" data-original-title="Editar Producto">
                                        <i class="fas fa-2x fa-pencil-alt"></i>
                              </a>
                              <?php echo e(csrf_field()); ?>

                              <span data-toggle="modal" data-target="#deletecate<?php echo e($cate->id); ?>">
                                  <a href="#!" class="table-action table-action-delete" data-toggle="tooltip" data-original-title="Eliminar Producto">
                                      <i class="fas fa-times-circle fa-2x text-danger"></i>
                                  </a>
                              </span>
                              <div class="modal fade" id="deletecate<?php echo e($cate->id); ?>" tabindex="-1" role="dialog" aria-labelledby="deluser" aria-hidden="true">
                                        <div class="modal-dialog modal-danger modal-dialog-centered modal-" role="document">
                                            <div class="modal-content bg-rojo">

                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>

                                                <div class="modal-body">

                                                    <div class="py-3 text-center">
                                                        <i class="ni ni-bell-55 ni-3x"></i>
                                                        <p class="negrita">¿Confirma que desea borrar <br> la categoría: <?php echo e($cate->nombre); ?>?</p>
                                                    </div>

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-white" data-dismiss="modal" onclick="deletecategoria(id=<?php echo e($cate->id); ?>);">Si</button>
                                                    <button type="button" class="btn btn-link text-white ml-auto" data-dismiss="modal">No</button>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <footer class="footer pt-0">
            <div class="row align-items-center justify-content-lg-between">
                <div class="col-lg-6">
                    <div class="copyright text-center  text-lg-left  text-muted">
                        &copy; 2020 <a href="https://barcodeapps.basisinventory.com/" class="font-weight-bold ml-1" target="_blank">BARCODEAPPS</a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <ul class="nav nav-footer justify-content-center justify-content-lg-end">
                        <li class="nav-item">
                            <a href="https://barcodeapps.basisinventory.com/" class="nav-link" target="_blank">Prueba Laravel de Jhon Jairo Ayala.</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link" target="_blank"></a>
                        </li>
                    </ul>
                </div>
            </div>
        </footer>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prueba-barcodeapps\resources\views/categorias/listado.blade.php ENDPATH**/ ?>