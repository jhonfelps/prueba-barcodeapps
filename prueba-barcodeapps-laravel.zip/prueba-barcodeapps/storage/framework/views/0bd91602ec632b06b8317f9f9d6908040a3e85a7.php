
<?php $__env->startSection('content'); ?>
<div class="header bg-naranja pb-6">
            <div class="container-fluid">
                <div class="header-body">
                    <div class="row align-items-center py-4">
                        <div class="col-lg-6 col-7">
                            <h6 class="h2 text-white d-inline-block mb-0">Crear Categoría</h6>
                        </div>
                        <div class="col-lg-6 col-5 text-right">
                            <a href="Categorias" class="btn btn-sm btn-neutral naranjabold">Listado de Categorías</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid mt--6">
            <!-- Table -->
            <div class="row justify-content-center">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row align-items-center">
                                <div class="col-8">
                                    <h3 class="mb-0">Formulario de Creación de Categoría</h3>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                          <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <span class="alert-text"><strong>Muy bien! </strong><?php echo \Session::get('success'); ?></span>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Cerrar">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <?php endif; ?>
                            <form action="SaveCategory" method="post" role="form" enctype="multipart/form-data">
                              <?php echo e(csrf_field()); ?>

                                <div class="pl-lg-4">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-nombre">Nombre</label>
                                                <input type="text" id="input-nombre" name="nombre" required class="form-control" placeholder="Nombre" value="" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-first-name">Descripción</label>
                                                <input type="text" id="input-codigo" name="descripcion" required class="form-control" placeholder="Descripción" value="" required>
                                            </div>
                                        </div>
                                      <div class="col-lg-12">
                                          <div class="text-center">
                                              <button type="submit" value="Guardar" class="btn btn-primary mt-4">Guardar</button>
                                          </div>
                                      </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prueba-barcodeapps\resources\views/categorias/agregar.blade.php ENDPATH**/ ?>