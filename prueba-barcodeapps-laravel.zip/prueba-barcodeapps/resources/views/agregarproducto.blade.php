@extends('templates.app')
@section('content')
<div class="header bg-naranja pb-6">
            <div class="container-fluid">
                <div class="header-body">
                    <div class="row align-items-center py-4">
                        <div class="col-lg-6 col-7">
                            <h6 class="h2 text-white d-inline-block mb-0">Crear Prodcuto</h6>
                        </div>
                        <div class="col-lg-6 col-5 text-right">
                            <a href="home" class="btn btn-sm btn-neutral naranjabold">Listado de Productos</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid mt--6">
            <!-- Table -->
            <div class="row justify-content-center">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row align-items-center">
                                <div class="col-8">
                                    <h3 class="mb-0">Formulario de Edición de Producto</h3>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                          @if (\Session::has('success'))
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <span class="alert-text"><strong>Muy bien! </strong>{!! \Session::get('success') !!}</span>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Cerrar">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            @endif
                            <form action="SaveProduct" method="post" role="form" enctype="multipart/form-data">
                              {{ csrf_field() }}
                                <div class="pl-lg-4">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-digito-verificacion">Categoría</label>
                                                <select class="form-control" id="categoria_id" name="categoria_id" required>
                                                    <option value="" selected disabled>Selecciona una categoría</option>
                                                    @foreach($categorias as $cate)
                                                    <option value="{{$cate->id}}">{{$cate->nombre}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-nombre">Nombre</label>
                                                <input type="text" id="input-nombre" name="nombre" required class="form-control" placeholder="Nombre" value="" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-first-name">Código</label>
                                                <input type="text" id="input-codigo" name="codigo" required class="form-control" placeholder="Código" value="" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-first-name">Color</label>
                                                <input type="text" id="input-color" name="color" required class="form-control" placeholder="Color" value="" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-3">
                                            <div class="form-group">
                                                <label class="form-control-label" for="input-first-name">Precio</label>
                                                <input type="number" id="input-precio" name="precio" required class="form-control" value="" placeholder="Precio" required>
                                            </div>
                                        </div>
                                      <div class="col-lg-12">
                                          <div class="text-center">
                                              <button type="submit" value="Guardar" class="btn btn-primary mt-4">Guardar</button>
                                          </div>
                                      </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
@endsection
