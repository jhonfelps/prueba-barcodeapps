﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
$(document).ready(function () {
    $('body').removeClass("g-sidenav-pinned").addClass("g-sidenav");
    $('ul.pagination').addClass('justify-content-end mb-0');
});
$('.datepicker').datepicker({
    language: 'es',
    autoclose: true,
    format: 'yyyy-mm-dd'
});
$('body').click(function () {
    $('body').removeClass("g-sidenav-pinned");
});
var code = {};
$("select[name='categoria_id'] > option").each(function () {
    if (code[this.text]) {
        $(this).remove();
    } else {
        code[this.text] = this.value;
    }
});
function deleteproducto(id) {
  var _token = $("input[name=_token]").val();
  console.log("token: "+_token);
    $.ajax(
        {
            type: 'POST',
            dataType: 'JSON',
            url: 'DeleteProduct',
            headers: {'X-CSRF-Token': _token},
            data: { id: id },
            success:
                function (response) {
                  Swal.fire({
                      title: 'Producto eliminado con exito!',
                      icon: 'success',
                      confirmButtonText: 'Ok'
                  }).then((result) => {
                      if (result.isConfirmed) {
                          location.reload();
                      }
                  })
                },
            error:
                function (response) {
                    alert("Error: " + response);
                }
        });
}
function deletecategoria(id) {
  var _token = $("input[name=_token]").val();
    $.ajax(
        {
            type: 'POST',
            dataType: 'JSON',
            url: 'DeleteCategory',
            headers: {'X-CSRF-Token': _token},
            data: { id: id },
            success:
                function (response) {
                  Swal.fire({
                      title: 'Categoría eliminada con exito!',
                      icon: 'success',
                      confirmButtonText: 'Ok'
                  }).then((result) => {
                      if (result.isConfirmed) {
                          location.reload();
                      }
                  })
                },
            error:
                function (response) {
                    alert("Error: " + response);
                }
        });
}
