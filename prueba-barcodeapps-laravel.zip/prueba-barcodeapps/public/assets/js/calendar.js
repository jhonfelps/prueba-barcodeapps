﻿$(document).ready(function () {

    $('#calendar').fullCalendar({
        eventLimit: true, // allow "more" link when too many events
        eventLimitText: "More", //sets the text for more events
        views: {
            timeGrid: {
                eventLimit: 6 // adjust to 6 only for timeGridWeek/timeGridDay
            }
        },
		header: {
			left: 'prev,next today',
			center: 'title',
			right: 'month,agendaWeek,agendaDay'
		},
		defaultDate: '2020-06-22',
        defaultView: 'month',
        lang: 'es',
        contentHeight: 1300,
        aspectRatio: 2,
        editable: true,
        navLinks: true,
        selectable: true,
        selectHelper: true,        
        select: function (start, end) {
            // Display the modal.
            // You could fill in the start and end fields based on the parameters
            $('.modal').modal('show');

        },
        eventClick: function (event, element) {
            // Display the modal and set the values to the event values.
            $('.modal').modal('show');
            $('.modal').find('#title').val(event.title);
            $('.modal').find('#starts-at').val(event.start);
            $('.modal').find('#ends-at').val(event.end);

        },
        editable: true,
        eventLimit: true, // allow "more" link when too many events

		events: [
            {
                id: 1,
                title: 'Vencimiento Fact.',
                start: '2020-06-18T12:00:00',
                allDay: true,
                className: 'bg-red',
                description: 'Nullam id dolor id nibh ultricies vehicula ut id elit. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.'
            },
            {
                id: 2,
                title: 'Rev. Nota Cred.',
                start: '2020-06-21',
                allDay: true,
                className: 'bg-orange',
                description: 'Nullam id dolor id nibh ultricies vehicula ut id elit. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.'
            },
            {
                id: 3,
                title: 'Recepción Mrc.',
                start: '2020-06-30',
                allDay: true,
                className: 'bg-green',
                description: 'Se recibió la mercancia de la factura fact465465'
            },
            {
                id: 4,
                title: 'Vencimiento de Factura.',
                start: '2020-06-30',
                allDay: true,
                className: 'bg-red',
                description: 'Vencimiento de la factura fact465465'
            },
            {
                id: 5,
                title: 'Vencimiento de Factura.',
                start: '2020-06-30',
                allDay: true,
                className: 'bg-red',
                description: 'Vencimiento de la factura fact465465'
            },
            {
                title: 'BCH237',
                start: '2019-08-12T10:30:00',
                end: '2019-08-12T11:30:00',
                extendedProps: {
                    department: 'BioChemistry'
                },
                description: 'Lecture'
            }
		]
	});

});