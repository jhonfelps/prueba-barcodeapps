<?php

use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/
//Productos
Route::get('/', 'App\Http\Controllers\ProductoController@index');
Route::get('home', 'App\Http\Controllers\ProductoController@index');
Route::get('/editar-producto={i}', 'App\Http\Controllers\ProductoController@editar')->name('editarproducto');
Route::post('/UpdateProduct', 'App\Http\Controllers\ProductoController@actualizar')->name('actualizarproducto');
Route::get('/Crear-Producto', 'App\Http\Controllers\ProductoController@crear');
Route::post('/SaveProduct', 'App\Http\Controllers\ProductoController@guardarnuevo')->name('guardarnuevo');
Route::post('/DeleteProduct', 'App\Http\Controllers\ProductoController@deleteproduct');

//Categorías
Route::get('Categorias', 'App\Http\Controllers\CategoriaController@index');
Route::get('/editar-categoria={i}', 'App\Http\Controllers\CategoriaController@editar');
Route::post('/UpdateCategory', 'App\Http\Controllers\CategoriaController@actualizar');
Route::get('/Crear-Categoria', 'App\Http\Controllers\CategoriaController@crear');
Route::post('/SaveCategory', 'App\Http\Controllers\CategoriaController@guardarnueva');
Route::post('/DeleteCategory', 'App\Http\Controllers\CategoriaController@deletecategoria');
