<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Categoria extends Model
{
    use HasFactory;
    protected $table = 'categorias';
    protected $fillable = ['nombre','descripcion'];
    protected $primaryKey = 'id';

    public static function verone($id)  {
      $producto = DB::table('categorias')
             ->where('id',$id)
             ->get()->toArray();
      return $producto;
    }
}
