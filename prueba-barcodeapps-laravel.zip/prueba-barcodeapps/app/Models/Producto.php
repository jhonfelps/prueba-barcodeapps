<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Producto extends Model
{
    use HasFactory;
    protected $table = 'productos';
    protected $fillable = ['nombre','categoria_id','codigo','color','precio'];
    protected $primaryKey = 'id';

    public static function verone($id)  {
      $producto = DB::table('productos')
            ->join('categorias', 'productos.categoria_id', '=', 'categorias.id')
             ->where('productos.id',$id)
             ->get(['productos.nombre','productos.codigo','productos.color','productos.id',
             'productos.precio','categorias.nombre as nombrecat','productos.categoria_id'])->toArray();
      return $producto;
    }
    public static function getproducts()  {
      $producto = DB::table('productos')
            ->join('categorias', 'productos.categoria_id', '=', 'categorias.id')
             ->get(['productos.nombre','productos.codigo','productos.color','productos.id',
             'productos.precio','categorias.nombre as nombrecat','productos.categoria_id', 'categorias.nombre as nombrecat'])->toArray();
      return $producto;
    }
}
