<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Producto;
use App\Models\Categoria;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class ProductoController extends Controller
{
  public function index()
  {
      $productos = Producto::getproducts();
      return view('home',compact('productos'));
  }
  public function editar($id)
  {
      $producto= Producto::verone($id);
      $categorias = Categoria::all();
      return view('editarproducto',compact('producto','categorias'));
  }
  public function actualizar(Request $request)
  {
      $inputs = $request->except(['_token']); $id=$request->input('id');
      Producto::where('id', $id)->update($inputs);
      return redirect()->back()->with('success', 'Producto actualizado!');
  }
  public function crear()
  {
      $categorias = Categoria::all();
      return view('agregarproducto', compact('categorias'));
  }
  public function guardarnuevo(Request $request)
  {
      $inputs = $request->all();
      $producto = Producto::create($inputs);
      $nuevoprd = $producto->id;
      return redirect()->back()->with('success', 'Producto guardardo con el id: <strong>'.$nuevoprd.'</strong>');
  }
  public function deleteproduct(Request $request)
  {
    DB::table('productos')->where('id', '=', $request->input('id'))->delete();
    return response()->json(['id' =>'Ok']);
  }
}
