<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Categoria;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class CategoriaController extends Controller
{
  public function index()
  {
      $categorias = Categoria::all();
      return view('categorias.listado',compact('categorias'));
  }
  public function editar($id)
  {
      $categoria = Categoria::verone($id);
      return view('categorias.editar',compact('categoria'));
  }
  public function actualizar(Request $request)
  {
      $inputs = $request->except(['_token']); $id=$request->input('id');
      Categoria::where('id', $id)->update($inputs);
      return redirect()->back()->with('success', 'Categoria actualizada!');
  }
  public function crear()
  {
      return view('categorias.agregar');
  }
  public function guardarnueva(Request $request)
  {
      $inputs = $request->all();
      $producto = Categoria::create($inputs);
      $nuevoprd = $producto->id;
      return redirect()->back()->with('success', 'Catagoría guardarda con el id: <strong>'.$nuevoprd.'</strong>');
  }
  public function deletecategoria(Request $request)
  {
    DB::table('categorias')->where('id', '=', $request->input('id'))->delete();
    return response()->json(['id' =>'Ok']);
  }
}
